if __name__ == '__main__':

    engine_path = "./human.engine"
    engine_path_pt = "./best_0301.engine"
    enigne_path_16class = "./best_0418.engine"
    nc = 16
    person_index = [0, 1, 2, 3]
    mask_index = [4, 5, 6]
    glove_index = [7, 8, 9]
    shoecover_index = [10, 11, 12]
    headgear_index = [13, 14, 15]
    image_dir = "/home/nvidia/zhou_gen/yolov7-main/data_classes16_0126/images/test"
    xml_dir = "/home/nvidia/zhou_gen/yolov7-main/data_classes16_0126/xml/test"
    save_path = "/home/nvidia/zhou_gen/yolov7-main/error_P_0.5_mask1_image"

    if os.path.exists(save_path):
        shutil.rmtree(save_path)

    if not os.path.exists(save_path):
        os.makedirs(save_path)
        print("路径不存在，已创建成功！")

    humandetector = HumanDetector(model_path=engine_path)
    humandetector_new = HumanDetector(model_path=enigne_path_16class)
    humandetector_pt = HumanDetector(model_path=engine_path_pt)

    confusion_matrix = ConfusionMatrix(nc = nc)
    confusion_matrix_new = ConfusionMatrix(nc = nc)
    confusion_matrix_pt = ConfusionMatrix(nc = nc)

    obj_count = 0
    pred_obj_count = 0
    conf = 0.5

    list_imgs = os.listdir(image_dir)

    for i in range(0, len(list_imgs)):
        TP, FP, FN = 0, 0, 0
        final_pred_label, final_pred_label_new, final_pred_label_pt, final_truth_label = [], [], [], []

        image_name = list_imgs[i]
        image_path = os.path.join(image_dir, image_name)
        (nameWithoutExtention, extention) = os.path.splitext(os.path.basename(image_path))
        xml_name = nameWithoutExtention + ".xml"
        xml_path = os.path.join(xml_dir, xml_name)
        truth_label = convert_annotation(xml_path)                                 # truth

        per_image = cv2.imread(image_path)
        img_copy = copy.deepcopy(per_image)
        pred_boxes = humandetector(per_image, conf_thres = conf)
        pred_boxes_new = humandetector_new(img_copy, conf_thres=conf)
        pred_boxes_pt = humandetector_pt(img_copy, conf_thres=conf)

        category_index = headgear_index

        for i in range(len(truth_label)):
            if int(truth_label[i][0]) in category_index:
                final_truth_label.append([truth_label[i][0], truth_label[i][1], truth_label[i][2], truth_label[i][3], truth_label[i][4]])

        # for i in range(len(pred_boxes)):
        #     if int(pred_boxes[i][-1]) in person_index:
        #         final_pred_label.append([pred_boxes[i][0], pred_boxes[i][1], pred_boxes[i][2], pred_boxes[i][3], pred_boxes[i][4],  pred_boxes_new[i][-1]])

        for i in range(len(pred_boxes_new)):
            if int(pred_boxes_new[i][-1]) in category_index:
                final_pred_label_new.append([pred_boxes_new[i][0], pred_boxes_new[i][1], pred_boxes_new[i][2], pred_boxes_new[i][3], pred_boxes_new[i][4], pred_boxes_new[i][-1]])

        for i in range(len(pred_boxes_pt)):
            if int(pred_boxes_pt[i][-1]) in category_index:
                final_pred_label_pt.append([pred_boxes_pt[i][0], pred_boxes_pt[i][1], pred_boxes_pt[i][2], pred_boxes_pt[i][3], pred_boxes_pt[i][4],  pred_boxes_pt[i][-1]])

        # import pdb; pdb.set_trace()

        # predn = torch.tensor(final_pred_label, dtype=torch.float32)                      # pred
        predn_new = torch.tensor(final_pred_label_new, dtype=torch.float32)
        predn_pt = torch.tensor(final_pred_label_pt, dtype=torch.float32)

        labels = torch.tensor(final_truth_label, dtype=torch.float32)

        mistake_new = confusion_matrix_new.process_batch(predn_new, labels, category_index=mask_index)
        mistake_pt = confusion_matrix_pt.process_batch(predn_pt, labels, category_index=mask_index)

        if mistake_new:
            H, W, s = per_image.shape
            size = (int(W * 0.5), int(H * 0.5))
            resize_image = cv2.resize(per_image, size)
            traget_image = copy.deepcopy(resize_image)
            pred_image = copy.deepcopy(resize_image)
            pred_image_pt = copy.deepcopy(resize_image)
            pred_image_new = copy.deepcopy(resize_image)

            for idx, value in enumerate(labels.tolist()):
                xmin = int(value[1] * 0.5)
                xmax = int(value[3] * 0.5)
                ymin = int(value[2] * 0.5)
                ymax = int(value[4] * 0.5)
                start_point = (xmin, ymin)
                end_point = (xmax, ymax)
                thickness = 5
                cls_key = int(value[0])
                color = colors(cls_key, True)
                cls_value = str(classes[cls_key])
                cv2.rectangle(traget_image, start_point, end_point, color, thickness)
                cv2.putText(traget_image, cls_value, start_point, cv2.FONT_HERSHEY_SIMPLEX, 1, color, 1)

            # plt_image(predn, pred_image)
            plt_image(predn_pt, pred_image_pt)
            plt_image(predn_new, pred_image_new)
            row1 = cv2.hconcat([traget_image, pred_image])
            row2 = cv2.hconcat([pred_image_pt, pred_image_new])
            result = cv2.vconcat([row1, row2])

            if per_image is not None and (per_image.any() if isinstance(per_image, (list, tuple)) else per_image.size > 0):
                output_file = os.path.join(save_path, nameWithoutExtention + ".jpg")
                cv2.imwrite(output_file, result)
            else:
                print("no image")