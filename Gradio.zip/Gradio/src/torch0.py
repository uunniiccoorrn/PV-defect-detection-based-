import torch
loss = torch.zeros(3)
print(loss)