import gradio as gr
import torch
import pandas as pd
from skimage import data
from PIL import Image
from torchkeras import plots
from torchkeras.data import get_url_img
from pathlib import Path
from ultralytics import YOLO
import ultralytics
from ultralytics.data import utils

model = YOLO(r"F:\available_cuda\RESULTS\yolov8-detect\train80\weights\best.pt")
# model = torch.hub.load("./", "custom", path=r"F:\available_cuda\RESULTS\yolov8-detect\yolov9-s2\weights\best.pt", source="local")

#prepare example images
# Image.fromarray(data.coffee()).save('coffee.jpeg')
# Image.fromarray(data.astronaut()).save('people.jpeg')
# Image.fromarray(data.cat()).save('cat.jpeg')

#load class_names
# yaml_path = str(Path(ultralytics.__file__).parent/'datasets/coco128.yaml')
class_names = ['scratches', 'broken grids', 'defaced']

def detect(img):
    if isinstance(img,str):
        img = get_url_img(img) if img.startswith('http') else Image.open(img).convert('RGB')
    result = model.predict(source=img)
    if len(result[0].boxes.data)>0:
        vis = plots.plot_detection(img,boxes=result[0].boxes.data,
                     class_names=class_names, min_score=0.2)
    else:
        vis = img
    return vis

# def detect(img, conf_thres, iou_thres):
#     model.conf = conf_thres
#     model.iou = iou_thres
#     return model(img).render()[0]

with gr.Blocks() as demo:
    gr.Markdown("# yolov8目标检测演示")

    with gr.Tab("选择测试图片"):
        files = ['0.jpg', '1.jpg', '2.jpg', '3.jpg']
        drop_down = gr.Dropdown(choices=files, value=files[0])
        button = gr.Button("执行检测", variant="primary")

        gr.Markdown("## 预测输出")
        out_img = gr.Image(type='pil')

        button.click(detect,
                     inputs=drop_down,
                     outputs=out_img)

    with gr.Tab("捕捉摄像头"):
        in_img = gr.Image(sources='webcam', type='pil')
        button = gr.Button("执行检测", variant="primary")

        gr.Markdown("## 预测输出")
        out_img = gr.Image(type='pil')

        button.click(detect,
                     inputs=in_img,
                     outputs=out_img)

    with gr.Tab("输入图片链接"):
        default_url = 'https://t7.baidu.com/it/u=3601447414,1764260638&fm=193&f=GIF'
        url = gr.Textbox(value=default_url)
        button = gr.Button("执行检测", variant="primary")

        gr.Markdown("## 预测输出")
        out_img = gr.Image(type='pil')

        button.click(detect,
                     inputs=url,
                     outputs=out_img)

    with gr.Tab("上传本地图片"):
        input_img = gr.Image(type='pil')
        button = gr.Button("执行检测", variant="primary")

        gr.Markdown("## 预测输出")
        out_img = gr.Image(type='pil')

        button.click(detect,
                     inputs=input_img,
                     outputs=out_img)

gr.close_all()
demo.queue(default_concurrency_limit=5)
demo.launch(share=True)