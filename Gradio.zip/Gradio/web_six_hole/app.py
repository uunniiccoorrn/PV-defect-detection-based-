from flask import Flask, request, jsonify, render_template, send_from_directory
import cv2
import os
from ultralytics import YOLO
from tqdm import tqdm
import torch
import copy
from PIL import Image, ImageDraw, ImageFont
import sys
import numpy as np
from pathlib import Path
from typing import Union
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import json, csv
import pandas as pd
import math
from flask import send_file
from flask_cors import CORS
from collections import OrderedDict

from sahi.utils.yolov8 import download_yolov8s_model
from sahi import AutoDetectionModel
from sahi.predict import get_sliced_prediction
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

app = Flask(__name__)

# 图像存储文件夹路径
IMAGE_FOLDER = '/data/shenyanbing/6_hole_save_images'
app.config['UPLOAD_FOLDER'] = IMAGE_FOLDER
app.config['CONTENT-TYPE'] = 'multipart/form-data'
fold_name = os.path.basename(IMAGE_FOLDER)
CORS(app)
concentration_completed = {}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/download', methods=['GET'])
def download_file():
    xlsx_file_path = "/data/shenyanbing/test_web_six_hole_v1/csv/6_hole_save_images.csv"
    return send_file(xlsx_file_path, as_attachment=True)

@app.route('/api/clear-files', methods=['POST'])
def clear_files():
    for filename in os.listdir(IMAGE_FOLDER):
        file_path = os.path.join(IMAGE_FOLDER, filename)
        if os.path.isfile(file_path):
            os.unlink(file_path)
    data_paths = [
        "test_web_six_hole_v1_copy1/data/analysis_results.json",
        "test_web_six_hole_v1_copy1/analysis/analysis_results.json"
    ]
    for path in data_paths:
        if os.path.exists(path):
            os.remove(path)
    concentration_completed.clear()
    return jsonify({"message": "All files deleted successfully"})

@app.route('/api/upload', methods=["POST"])
def upload_files():
    files = request.files.getlist("files[]")
    for file in files:
        image_save_path = os.path.join(IMAGE_FOLDER, file.filename)
        file.save(image_save_path)
    return jsonify({"message": "Files uploaded successfully"})


@app.route('/api/images', methods=['GET'])
def get_images():
    image_files = [f for f in os.listdir(IMAGE_FOLDER) if f.endswith('.JPG')]
    image_paths = [
        {
            'path': f'/static/images/{filename}',
            'concentrationCompleted': concentration_completed.get(filename, False)
        }
        for filename in image_files
    ]
    return jsonify(image_paths)


@app.route('/static/images/<filename>')
def serve_image(filename):
    return send_from_directory(IMAGE_FOLDER, filename)


@app.route('/api/analyze', methods=['POST'])
def analyze_image():
    data = request.json
    image_path = data['imagePath']
    full_path = convert_url_to_path(image_path)
    filename = os.path.basename(full_path)
    concentrations = data.get('concentrations', [])  # 获取浓度值列表，默认为空列表
    try:
        image = cv2.imread(full_path)
        if image is None:
            return jsonify({"error": "Image not found"}), 404
        analysis_result = analyze_concentrations(image, concentrations)
        concentration_completed[filename] = True
        # 准备保存的数据
        result_data = {"filename": filename, "analysis_result": analysis_result}
        # 保存数据
        save_analysis_results(result_data, concentrations=True, analyze=False)
        return jsonify(result_data)
    except Exception as e:
        # 如果出现错误，返回错误信息
        return jsonify({"error": str(e)}), 500


VIS_FOLDER = '/data/shenyanbing/test_web_six_hole_v1_copy1/static/VIS'


@app.route('/get_images_urls', methods=['GET'])
def get_images_urls():
    try:
        # 获取文件夹内所有图片文件名
        images = [f for f in os.listdir(VIS_FOLDER) if os.path.isfile(os.path.join(VIS_FOLDER, f))]

        # 构造图片URL列表，假设你的应用是通过相对路径提供图片的
        image_urls = [f'/static/VIS/{image}' for image in images]

        return jsonify(image_urls)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/analyze-all', methods=['POST'])
def analyze_all_images():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    concentrations_file_path = os.path.join(BASE_DIR, "data")
    concentrations_file = os.path.join(concentrations_file_path, 'analysis_results.json')
    concentrations_results = read_json_file(concentrations_file)
    concentrat_filename = [item['filename'] for item in concentrations_results]

    for filename in os.listdir(IMAGE_FOLDER):
        if filename in concentrat_filename:
            full_path = os.path.join(IMAGE_FOLDER, filename)
            if filename.endswith('.JPG'):
                image = cv2.imread(full_path)
            if image is None:
                return jsonify({"error": "Image not found"}), 404
            print("filename:", filename)
            per_image_rate = circle_detect(full_path)
            result_data = {"filename": filename, "per_image_rate": per_image_rate}
            save_analysis_results(result_data, concentrations=False, analyze=True)

    analyze_file_path = os.path.join(BASE_DIR, "analysis")
    analyze_file = os.path.join(analyze_file_path, 'analysis_results.json')
    analysis_results = read_json_file(analyze_file)
    analyze_csv_path = os.path.join(BASE_DIR, "csv")
    analyze_csv = os.path.join(analyze_csv_path, fold_name + ".csv")
    if not os.path.exists(analyze_csv_path):
        os.makedirs(analyze_csv_path)

    analysis_filenames = {item['filename'] for item in analysis_results}
    concentration_filenames = {item['filename'] for item in concentrations_results}
    common_filenames = analysis_filenames.intersection(concentration_filenames)
    common_analysis_results = [value for idx, value in enumerate(analysis_results) if value["filename"] in concentration_filenames]

    from collections import defaultdict
    import math
    from collections import OrderedDict

    # Step 1: Extract prefixes
    prefixes = [result["filename"][:-7] for result in analysis_results]

    # Step 2: Group by prefix
    grouped_results = defaultdict(list)
    for result, prefix in zip(analysis_results, prefixes):
        grouped_results[prefix].append(result)

    # Step 3: Merge per_image_rate lists within each group and create new dictionaries
    analysis_results = []
    for prefix, results in grouped_results.items():
        merged_per_image_rates = []
        results = sorted(results, key=lambda item: int(item['filename'].split('-')[-1].split('.')[0]))
        for result in results:
            merged_per_image_rates.extend(result["per_image_rate"])

        # Create the final dictionary with the merged data
        new_result = {
            "filename": f"{prefix}.JPG",  # Use the prefix without the suffix as the filename
            "per_image_rate": merged_per_image_rates
        }
        analysis_results.append(new_result)
    merged_results = {}
    from collections import defaultdict

    def sort_and_merge_concentrations(concentrations_results):
        sorted_concentrations = defaultdict(list)

        for item in concentrations_results:
            filename = item["filename"]
            prefix = "-".join(filename.split("-")[:2]).split('.JPG')[0]
            suffix_num = int(filename.split("-")[-1].split(".")[0])

            concentrations = item["analysis_result"]["concentrations"]
            sorted_concentrations[prefix].append((suffix_num, concentrations))

        merged_results = {}
        for prefix, concentration_tuples in sorted_concentrations.items():
            concentrations = [c for _, cs in sorted(concentration_tuples) for c in cs]
            merged_results[prefix] = {
                "filename": prefix + ".JPG",
                "analysis_result": {
                    "concentrations": concentrations
                }
            }

        return list(merged_results.values())

    concentrations_results = sort_and_merge_concentrations(concentrations_results)

    def merge_analysis_results(analysis_results, concentrations_results):
        common_analysis_results = []

        # Create a dictionary to map file names to their corresponding analysis results
        analysis_dict = {result['filename']: result for result in analysis_results}

        for concentration_result in concentrations_results:
            filename = concentration_result["filename"]
            concentrations = concentration_result["analysis_result"]["concentrations"]

            # Get the corresponding analysis result for this file
            if filename not in analysis_dict:
                continue
            per_image_rate = analysis_dict[filename]['per_image_rate']

            # Group per_image_rate sublists by the corresponding concentrations
            grouped_rates = {}
            for rate, conc in zip(per_image_rate, concentrations):
                if conc not in grouped_rates:
                    grouped_rates[conc] = []
                grouped_rates[conc].append(rate)

            # Merge sublists that correspond to duplicate concentrations
            merged_per_image_rate = []
            for conc, rates in grouped_rates.items():
                if len(rates) > 1:
                    merged_per_image_rate.append(rates)
                else:
                    merged_per_image_rate.extend(rates)

            common_analysis_results.append({
                'filename': filename,
                'per_image_rate': merged_per_image_rate
            })

        return common_analysis_results

    # 获取共同数据common_analysis_results
    common_analysis_results = merge_analysis_results(analysis_results, concentrations_results)

    # print(common_analysis_results)

    # 获取合并后的浓度梯度数据
    def sort_and_remove_duplicate_concentrations(concentrations_results):
        updated_list = []
        for item in concentrations_results:
            concentrations = item['analysis_result']['concentrations']
            unique_concentrations = list(OrderedDict.fromkeys(concentrations))
            item['analysis_result']['concentrations'] = unique_concentrations
            updated_list.append(item)
        return (updated_list)

    # Apply the function to your provided data
    concentrations_results = sort_and_remove_duplicate_concentrations(concentrations_results)
    # 定义列名
    column_names = ['filename'] + [f'10^-{i}' for i in range(9)]
    csv_file_path = '/data/shenyanbing/test_web_six_hole_v1/csv/6_hole_save_images.csv'
    # 打开CSV文件进行写入
    with open(csv_file_path, 'w', newline='') as csvfile:
        # 创建一个CSV writer对象
        writer = csv.writer(csvfile)

        # 写入表头
        writer.writerow(column_names)

        # 写入数据
        for result in analysis_results:
            row_data = [result['filename']] + ['NULL'] * (len(column_names) - 1)
            writer.writerow(row_data)

    results = {}

    # 遍历common_analysis_results
    for common_result in common_analysis_results:
        filename = common_result['filename']
        per_image_rate = common_result['per_image_rate']

        # 遍历concentrations_results
        for conc_result in concentrations_results:
            if conc_result['filename'] == filename:
                concentrations = conc_result['analysis_result']['concentrations']
                # 将结果存储到字典中
                results[filename] = {'per_image_rate': per_image_rate, 'concentrations': concentrations}
                break

    with open(csv_file_path, mode='r') as file:
        reader = csv.DictReader(file)
        rows = []
        for row in reader:
            row['filename'] = row['filename'].replace('.JPG', '')
            row = {key: 'NA' if value == 'NULL' else value for key, value in row.items()}
            rows.append(row)

    for filename, data in results.items():
        per_image_rate = data['per_image_rate']
        concentrations = data['concentrations']
        concentrations_float = [float(concentration) for concentration in concentrations]
        sorted_data = sorted(zip(concentrations_float, per_image_rate))

        # 找到对应的行
        for row in rows:
            if row['filename'] == filename.replace('.JPG', ''):
                # 更新per_image_rate的值
                TNTC_flog = False
                for idx, value in enumerate(sorted_data):
                    per_concentrations, per_rate = value
                    exponent = int(-math.log10(per_concentrations))
                    rates_str = str(per_rate).replace("[", "").replace("]", "")
                    rates = list(map(int, rates_str.split(',')))
                    column_name = f'10^-{exponent}'
                    if TNTC_flog:
                        row[column_name] = str('TNTC * ') + str(len(rates))
                        continue
                    if all(rate >= 10 for rate in rates):
                        row[column_name] = str(per_rate).replace("[", "").replace("]",
                                                                                  "") if per_rate is not None else 'NA'
                        TNTC_flog = True
                        continue
                    row[column_name] = str(per_rate).replace("[", "").replace("]",
                                                                              "") if per_rate is not None else 'NA'
                break

    # 将更新后的数据写回CSV文件
    with open(csv_file_path, mode='w', newline='') as file:
        fieldnames = rows[0].keys()
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print("分析结束")
    return jsonify({"message": "Analysis completed for all images", "results": len(common_filenames)})


@app.route('/api/setConcentrations', methods=['POST'])
def set_concentrations():
    data = request.json
    per_image_concentrations = data['concentrations']
    # Process received concentration values
    print(per_image_concentrations)


def save_to_json(data, file_path):
    with open(file_path, 'w') as f:
        json.dump(data, f, indent=4)


def analyze_concentrations(image, concentrations):
    # Implement the actual analysis logic here, returning the analysis result
    # This is just an example
    return {"concentrations": concentrations}


def read_json_file(filename):
    with open(filename, 'r') as file:
        return json.load(file)


def kmean_w(your_list):
    # Implementation of kmean_w function
    pass


def calculate_iou(box1, box2):
    # Calculation of Intersection over Union (IOU)
    pass


def remove_overlapping_boxes(boxes, iou_threshold=0.7):
    # Remove overlapping bounding boxes based on IOU threshold
    pass


def find_max_variable(MVM, X_MuLV, PrV):
    # Determine which variable is maximum
    pass


def circle_detect(images_path):
    # Function to detect circles and process the image
    pass

def process_result_circle(result_circle):
    # Processing for the first list in the tuple
    result_circle[0] = sorted(result_circle[0], key=lambda x: x[0], reverse=True)
    if len(result_circle[0]) < 3:
        flog_0, flog_1, flog_2 = 0, 0, 0
        for i in range(len(result_circle[0])):
            center_x = result_circle[0][i][0]
            if 1 < center_x < 2200:
                flog_2 = 1
            elif 2400 < center_x < 4200:
                flog_1 = 1
            elif 4800 < center_x < 7200:
                flog_0 = 1
        if flog_0 == 0 and flog_1 == 0 and flog_2 == 1:
            result_circle[0].append([])
            result_circle[0].append([])
            result_circle[0][2] = result_circle[0][0]
            result_circle[0][1] = [x + (i == 0 and 2147) for i, x in enumerate(result_circle[0][2])]
            result_circle[0][0] = [x + (i == 0 and 2147) for i, x in enumerate(result_circle[0][1])]

        if flog_0 == 0 and flog_1 == 1 and flog_2 == 0:
            result_circle[0].append([])
            result_circle[0].append([])
            result_circle[0][1] = result_circle[0][0]
            result_circle[0][2] = [x - (i == 0 and 2147) for i, x in enumerate(result_circle[0][1])]
            result_circle[0][0] = [x + (i == 0 and 2147) for i, x in enumerate(result_circle[0][1])]

        if flog_0 == 1 and flog_1 == 0 and flog_2 == 0:
            result_circle[0].append([])
            result_circle[0].append([])
            result_circle[0][1] = [x - (i == 0 and 2147) for i, x in enumerate(result_circle[0][0])]
            result_circle[0][2] = [x - (i == 0 and 2147) for i, x in enumerate(result_circle[0][1])]

        if flog_0 == 0 and flog_1 == 1 and flog_2 == 1:
            result_circle[0].append([])
            result_circle[0][2] = result_circle[0][1]
            result_circle[0][1] = result_circle[0][0]
            result_circle[0][0] = [x + (i == 0 and 2147) for i, x in enumerate(result_circle[0][1])]

        if flog_0 == 1 and flog_1 == 0 and flog_2 == 1:
            result_circle[0].append([])
            result_circle[0][2] = result_circle[0][1]
            result_circle[0][1] = [x - (i == 0 and 2147) for i, x in enumerate(result_circle[0][0])]

        if flog_0 == 1 and flog_1 == 1 and flog_2 == 0:
            result_circle[0].append([])
            result_circle[0][2] = [x - (i == 0 and 2147) for i, x in enumerate(result_circle[0][1])]

    if len(result_circle[1]) < 3:
        flog_0, flog_1, flog_2 = 0, 0, 0
        for i in range(len(result_circle[1])):
            center_x = result_circle[1][i][0]
            if 1 < center_x < 2200:
                flog_2 = 1
            elif 2400 < center_x < 4200:
                flog_1 = 1
            elif 4800 < center_x < 7200:
                flog_0 = 1
        if flog_0 == 0 and flog_1 == 0 and flog_2 == 0:
            result_circle[1].append([])
            result_circle[1].append([])
            result_circle[1].append([])
            result_circle[1][2] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][2])]
            result_circle[1][1] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][1])]
            result_circle[1][0] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][0])]

        if flog_0 == 0 and flog_1 == 0 and flog_2 == 1:
            result_circle[1].append([])
            result_circle[1].append([])
            result_circle[1][2] = result_circle[1][0]
            result_circle[1][1] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][1])]
            result_circle[1][0] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][0])]

        if flog_0 == 0 and flog_1 == 1 and flog_2 == 0:
            result_circle[1].append([])
            result_circle[1].append([])
            result_circle[1][1] = result_circle[1][0]
            result_circle[1][2] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][2])]
            result_circle[1][0] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][0])]

        if flog_0 == 1 and flog_1 == 0 and flog_2 == 0:
            result_circle[1].append([])
            result_circle[1].append([])
            result_circle[1][2] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][2])]
            result_circle[1][1] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][1])]

        if flog_0 == 0 and flog_1 == 1 and flog_2 == 1:
            result_circle[1].append([])
            result_circle[1][2] = result_circle[1][1]
            result_circle[1][1] = result_circle[1][0]
            result_circle[1][0] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][0])]

        if flog_0 == 1 and flog_1 == 0 and flog_2 == 1:
            result_circle[1].append([])
            result_circle[1][2] = result_circle[1][1]
            result_circle[1][1] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][1])]

        if flog_0 == 1 and flog_1 == 1 and flog_2 == 0:
            result_circle[1].append([])
            result_circle[1][2] = [x + (i == 1 and 2147) for i, x in enumerate(result_circle[0][2])]

    return result_circle

def compare_lists(a, b):
    # If either list a or b has fewer than 3 elements, return the unmatched list
    if len(a) < 3:
        for item in b:
            if abs(item[0] - a[0][0]) < 150:
                return a
        return b
    elif len(b) < 3:
        for item in a:
            if abs(item[0] - b[0][0]) < 150:
                return b
        return a
    else:
        return None  # Return None if neither list has fewer than 3 elements

def save_analysis_results(data, concentrations=False, analyze=False):
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    if concentrations:
        DATA_DIR = os.path.join(BASE_DIR, 'data')
        RESULTS_FILE = os.path.join(DATA_DIR, 'analysis_results.json')
    elif analyze:
        DATA_DIR = os.path.join(BASE_DIR, 'analysis')
        RESULTS_FILE = os.path.join(DATA_DIR, 'analysis_results.json')
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    if not os.path.exists(RESULTS_FILE):
        with open(RESULTS_FILE, 'w') as file:
            json.dump([], file)  # Create an empty JSON list if the file doesn't exist

    with open(RESULTS_FILE, 'r+') as file:
        file_data = json.load(file)
        existing_entry = next((item for item in file_data if item['filename'] == data['filename']), None)
        if existing_entry:
            existing_entry.update(data)
        else:
            file_data.append(data)
        file.seek(0)
        file.truncate()
        json.dump(file_data, file, indent=4)

def convert_url_to_path(image_url):
    # Implement the logic to convert an image URL to the actual file path on the server
    filename = os.path.basename(image_url)
    return os.path.join(IMAGE_FOLDER, filename)


if __name__ == '__main__':
    config_path = '/data/shenyanbing/11.17/ultralytics-main/ultralytics/models/yolo/model.py'
    model_path = '/data/shenyanbing/11.17/VCS_6/best.pt'
    save_folder = "/data/shenyanbing/11.17/VCS_6/demo/1111/"
    new_image_path = "/data/shenyanbing/test_web_six_hole_v1_copy1/static/VIS"
    if os.path.exists(new_image_path):
        import shutil
        shutil.rmtree(new_image_path)
    os.makedirs(new_image_path)

    slice_height = 640
    slice_width = 640
    overlap_height_ratio = 0.4
    overlap_width_ratio = 0.4

    detection_model = AutoDetectionModel.from_pretrained(
        model_type='yolov8',
        model_path=model_path,
        config_path=config_path,
        confidence_threshold=0.3,
        device="cpu"
    )
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)

    app.run(host='0.0.0.0', port=5033)