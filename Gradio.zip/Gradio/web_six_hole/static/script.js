document.addEventListener('DOMContentLoaded', function() {
    loadAndDisplayImages();

    document.getElementById('loadImages').addEventListener('click', function() {
        fetch('/api/images')
            .then(response => response.json())
            .then(data => {
                displayImages(data);
            })
            .catch(error => console.error('Error:', error));
    });

    const plateTypeSelect = document.getElementById('plateType');
    plateTypeSelect.addEventListener('change', function() {
        const plateType = this.value;
        let dropdownCount = 0;

        if (plateType === '6') {
            dropdownCount = 2;
        } else if (plateType === '96') {
            dropdownCount = 12;
        }

        createDropdowns(dropdownCount);
    });

    createDropdowns(2);
});

function loadAndDisplayImages() {
    fetch('/api/images')
        .then(response => response.json())
        .then(data => {
            displayImages(data);
        })
        .catch(error => console.error('Error:', error));
}

function displayImages(data) {
    const imageDisplay = document.getElementById('imageDisplay');
    imageDisplay.innerHTML = '';

    data.forEach(item => {
        const imageUrl = item.path;
        const imageName = imageUrl.split('/').pop().split('.')[0];
        const concentrationCompleted = item.concentrationCompleted;

        const imageWrapper = document.createElement('div');
        imageWrapper.style.position = 'relative';
        imageWrapper.style.display = 'inline-block';

        const nameDiv = document.createElement('div');
        nameDiv.textContent = imageName;
        nameDiv.className = 'name-div';

        const img = document.createElement('img');
        img.src = imageUrl;
        img.className = 'responsive-image';
        if (concentrationCompleted) {
            img.style.border = '3px solid red';
        }
        img.addEventListener('click', () => {
            displayImageDetails(imageUrl);
        });

        imageWrapper.appendChild(nameDiv);
        imageWrapper.appendChild(img);
        imageDisplay.appendChild(imageWrapper);
    });
}

function displayImageDetails(imageUrl) {
    const imageDisplay = document.getElementById('imageDisplay');
    imageDisplay.innerHTML = '';

    const imageName = imageUrl.split('/').pop().split('.')[0];

    const imageNameDiv = document.createElement('div');
    imageNameDiv.textContent = imageName;
    imageNameDiv.style.textAlign = 'center';
    imageNameDiv.style.margin = '10px 0';
    imageDisplay.appendChild(imageNameDiv);

    const clickedImg = document.createElement('img');
    clickedImg.src = imageUrl;
    clickedImg.className = 'enlarged-image';
    imageDisplay.appendChild(clickedImg);

    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.justifyContent = 'center';
    buttonContainer.style.gap = '10px';

    const analyzeButton = document.createElement('button');
    analyzeButton.innerText = '标记浓度设定完毕';
    analyzeButton.addEventListener('click', () => {
        markConcentrationComplete(imageUrl);
    });
    buttonContainer.appendChild(analyzeButton);

    const backButton = document.createElement('button');
    backButton.innerText = '返回主界面';
    backButton.addEventListener('click', function() {
        loadAndDisplayImages();
    });
    buttonContainer.appendChild(backButton);
    imageDisplay.appendChild(buttonContainer);
}

function markConcentrationComplete(imageUrl) {
    const concentrations = Array.from(document.querySelectorAll('#dropdownsContainer select')).map(select => select.value);
    console.log(JSON.stringify({ imagePath: imageUrl, concentrations: concentrations }));

    fetch('/api/analyze', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ imagePath: imageUrl, concentrations: concentrations }),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Analysis complete', data);
        loadAndDisplayImages();
    })
    .catch(error => console.error('Error analyzing image:', error));
}

// 用于创建指定数量的下拉框并填充内容
function createDropdowns(count) {
    const container = document.getElementById('dropdownsContainer');
    container.innerHTML = ''; // 清空旧的下拉框

    for (let i = 0; i < count; i++) {
        const dropdown = document.createElement('select');

        for (let exp = -8; exp <= 0; exp++) {
            const option = document.createElement('option');
            option.value = `1e${exp}`;
            option.textContent = `10^(${exp})`;
            dropdown.appendChild(option);
        }

        container.appendChild(dropdown);
    }
}

document.getElementById('analyzeAllImages').addEventListener('click', function() {
    fetch('/api/analyze-all', { method: 'POST' })
        .then(response => response.json())
        .then(data => alert('所有图片分析完成，分析了 ' + data.results + ' 张图片。'))
        .catch(error => console.error('Error analyzing all images:', error));
});

document.getElementById('downloadButton').addEventListener('click', function() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/api/download', true);
    xhr.responseType = 'blob';

    xhr.onload = function() {
        if (this.status === 200) {
            var blob = new Blob([xhr.response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            var url = window.URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = 'Six_Analyze_results.csv';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
        }
    };

    xhr.send();
});

document.getElementById('uploadButton').addEventListener('click', function() {
    var fileInput = document.getElementById('fileInput');

    if (fileInput.files.length === 0) {
        alert('Please select one or more files to upload.');
        return;
    }

    var formData = new FormData();
    var files = [];
    for (var i = 0; i < fileInput.files.length; i++) {
        var file = fileInput.files[i];
        files.push(file);
        formData.append('files[]', file);
    }

    fetch('/api/upload', { method: 'POST', body: formData })
        .then(response => {
            if (response.ok) {
                alert('File uploaded successfully!');
            } else {
                alert('Error uploading file:', response.statusText);
            }
        });
});

document.getElementById('clearButton').addEventListener('click', function() {
    fetch('/api/clear-files', { method: 'POST' })
        .then(response => response.json())
        .then(data => alert(data.message))
        .catch(error => console.error('Error clearing files:', error));
});

document.getElementById('visButton').addEventListener('click', async function() {
    try {
        const response = await fetch('/get_images_urls');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const imageUrls = await response.json();

        const style = document.createElement('style');
        style.textContent = `
            .image-container-style {
                max-width: 100%;
                display: block;
                margin: 0 auto;
            }
            .image-container-style img {
                width: 100%;
                height: auto;
                display: block;
            }
            #imageSelector {
                margin-bottom: 10px;
            }
        `;
        document.head.appendChild(style);

        let container = document.getElementById('imageContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'imageContainer';
            container.classList.add('image-container-style');
            document.body.appendChild(container);
        }

        const selector = document.createElement('select');
        selector.id = 'imageSelector';

        const defaultOption = document.createElement('option');
        defaultOption.text = '请选择一张图像';
        selector.appendChild(defaultOption);

        imageUrls.forEach((url, index) => {
            const fileNameWithoutExtension = url.split('/').pop().split('.')[0];
            const option = document.createElement('option');
            option.value = url;
            option.text = fileNameWithoutExtension;
            selector.appendChild(option);
        });

        selector.addEventListener('change', function(event) {
            const selectedUrl = event.target.value;
            if (selectedUrl) {
                container.innerHTML = '';
                const imgElement = document.createElement('img');
                imgElement.src = selectedUrl;
                imgElement.alt = '可视化图像';
                container.appendChild(imgElement);
            }
        });

        document.body.insertBefore(selector, container);
    } catch (error) {
        console.error('Error fetching image URLs:', error);
    }
});