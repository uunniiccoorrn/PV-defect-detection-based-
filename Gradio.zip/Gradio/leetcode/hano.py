#  输入：A = [2, 1, 0], B = [], C = []
#  输出：C = [2, 1, 0]

class Solution:
    def hanota(self, A, B, C):
        n = len(A)
        return self.move(n, A, B, C)
    def move(self, n, A, B, C):
        if n == 1:
            C.append(A.pop())
        else:
            self.move(n-1, A, C, B)
            C.append(A.pop())
            self.move(n-1, B, A, C)
        return A, B, C

# class Solution:
#     def hanota(self, A, B, C) -> None:
#         """
#         Do not return anything, modify C in-place instead.
#         """
#         n = len(A)
#         self.move(n, A, B, C)
#         return A, B, C
#
#     def move(self, n, A, B, C):
#         if n == 1:
#             C.append(A.pop())
#         else:
#             self.move(n - 1, A, C, B)
#             C.append(A.pop())
#             self.move(n - 1, B, A, C)

hano = Solution()
A = [2, 1, 0]
B = []
C = []
result = hano.hanota(A, B, C)
print(result)