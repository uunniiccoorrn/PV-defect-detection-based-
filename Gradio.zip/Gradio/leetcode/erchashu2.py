from typing import List, Optional

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

# class Solution:
#     def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
#         result = []
#         stack = []
#         cur = root
#         while cur or stack:
#             if cur != None:
#                 stack.append(cur)
#                 cur = cur.left
#             else:
#                 cur = stack.pop()
#                 result.append(cur.val)
#                 cur = cur.right

#         return result

class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        result = []
        stack = []
        cur = root
        while cur:
            if cur != None:
                result.append(cur.val)
                cur = cur.left
                # stack.append(cur)
                
            else:
                # cur = stack.pop()
                cur = cur.right
                

        return result



    
# 创建二叉树节点
root = TreeNode(3)
# root = None
root.left = TreeNode(9)
root.right = TreeNode(20)
root.right.left = TreeNode(15)
root.right.right = TreeNode(7)

# 创建 Solution 类实例并调用 levelOrder 方法
solution = Solution()
result = solution.levelOrder(root)

# 打印层次遍历结果
print(result)