from typing import List, Optional

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        if root is None:
            return []

        result = []
        queue = [root]

        while queue:
            # 获取当前层的所有节点值
            current_level_values = [node.val for node in queue]
            result.append(current_level_values)

            # 更新队列，添加下一层的所有节点
            next_queue = []
            for node in queue:
                if node.left:
                    next_queue.append(node.left)
                if node.right:
                    next_queue.append(node.right)
            queue = next_queue

        return result
    
# 创建二叉树节点
# root = TreeNode(3)
root = None
# root.left = TreeNode(9)
# root.right = TreeNode(20)
# root.right.left = TreeNode(15)
# root.right.right = TreeNode(7)

# 创建 Solution 类实例并调用 levelOrder 方法
solution = Solution()
result = solution.levelOrder(root)

# 打印层次遍历结果
print(result)