from typing import List, Optional

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        result = []
        return self.mid(root, result)
    def mid(self, node, result):
        if node is None:
            return
        self.mid(node.left, result)
        result.append(node.val)
        self.mid(node.right, result)
        return result

    
# 创建二叉树节点
root = TreeNode(3)
# root = None
root.left = TreeNode(9)
root.right = TreeNode(20)
root.left.left = TreeNode(15)
root.left.right = TreeNode(7)

# 创建 Solution 类实例并调用 levelOrder 方法
solution = Solution()
result = solution.levelOrder(root)

# 打印层次遍历结果
print(result)