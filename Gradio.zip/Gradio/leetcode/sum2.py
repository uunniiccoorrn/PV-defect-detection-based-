# 一刷nums = [2,7,11,15], target = 9，返回[0, 1]

# class SUM:
#     def __init__(self, nums, target) -> None:
#         self.nums = nums
#         self.target = target
#     def function_baoli(self):
#         for idx, i in enumerate(self.nums):
#             for idx1, j in enumerate(self.nums):
#                 if i + j == self.target:
#                     return [idx, idx1]
#     def haxi(self):
#         dict = {}
#         for idx, i in enumerate(self.nums):
#             if self.target - i not in dict:
#                 dict[i] = idx
#             else:
#                 return [dict[self.target - i], idx]
#
# nums = [2, 7, 11, 15]
# target = 9
# sum = SUM(nums, target)
# result = sum.function_baoli()
# print(result)
# result1 = sum.haxi()
# print(result1)

# 二刷nums = [2,7,11,15], target = 9，返回[0, 1]
# class SUM:
#     def __init__(self, sums, target):
#         self.sums = sums
#         self.target = target
#         self.n = len(sums)
#     def baoli(self):
#         for i in range(self.n):
#             for j in range(i+1, self.n):
#                 if self.sums[i] + self.sums[j] == self.target:
#                     return [i, j]
#     def haxi(self):
#         record = {}
#         for idx, value in enumerate(self.sums):
#             if self.target-self.sums[idx] not in record:
#                 record[value] = idx
#             else:
#                 return [record[self.target-value], idx]

# 三刷nums = [2,7,11,15], target = 9，返回[0, 1]
class SUM:
    def __init__(self, nums, target):
        self.nums = nums
        self.target = target
    def haxi(self):
        record = {}
        for idx, value in enumerate(self.nums):
            if self.target - value not in record:
                record[value] = idx
            else:
                return [record[self.target - value], idx]
    def baoli(self):
        for i in range(len(self.nums)):
            for j in range(i + 1, len(self.nums)):
                if self.nums[i] + self.nums[j] == self.target:
                    return [i, j]


sums = [2, 7, 11, 15]
target = 9
sum = SUM(sums, target)
result1 = sum.baoli()
result2 = sum.haxi()
print(result1, result2)