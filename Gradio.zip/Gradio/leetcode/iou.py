import numpy as np

def intersection_area(rect1, rect2):
    """
    计算两个矩形区域的交集面积
    """
    x1_min = max(rect1[0], rect2[0])
    y1_min = max(rect1[1], rect2[1])
    x1_max = min(rect1[2], rect2[2])
    y1_max = min(rect1[3], rect2[3])

    if x1_max < x1_min or y1_max < y1_min:
        return 0  # 无交集

    intersection_width = x1_max - x1_min
    intersection_height = y1_max - y1_min

    return intersection_width * intersection_height


def union_area(rect1, rect2):
    """
    计算两个矩形区域的并集面积
    """
    area_rect1 = (rect1[2] - rect1[0]) * (rect1[3] - rect1[1])
    area_rect2 = (rect2[2] - rect2[0]) * (rect2[3] - rect2[1])

    return area_rect1 + area_rect2 - intersection_area(rect1, rect2)


def iou(rect1, rect2):
    """
    计算两个矩形区域的交并比（Intersection over Union, IoU）
    """
    intersection = intersection_area(rect1, rect2)
    union = union_area(rect1, rect2)

    return intersection / union


# def check_all_pairs_iou(info, threshold=0.95):
#     """
#     遍历info列表，寻找类别为clothes_upright或headgear的所有目标，
#     对这些目标进行两两比对，如果任意一对的交并比大于指定阈值，则返回True
#     """
#     target_classes = ['clothes_upright', 'headgear']
#     target_rects = []
#
#     for rect in info:
#         if rect[-1] in target_classes:
#             target_rects.append(rect[:-1])  # 前四个元素表示矩形坐标
#
#     if len(target_rects) < 2:
#         return False  # 不足两对目标进行比对
#
#     for i in range(len(target_rects)):
#         for j in range(i + 1, len(target_rects)):
#             iou_value = iou(target_rects[i], target_rects[j])
#             if iou_value >= threshold:
#                 return True
#
#     return False

# def check_all_pairs_iou(info, threshold=0.95):
#     """
#     遍历info列表，寻找类别为headgear和clothes_upright的目标，
#     如果存在这样的目标对，比较它们的交并比，如果交并比大于指定阈值，则返回True
#     """
#     target_classes = {'headgear': None, 'clothes_upright': None}
#
#     for rect in info:
#         if rect[-1] in target_classes:
#             target_classes[rect[-1]] = rect[:-1]  # 前四个元素表示矩形坐标
#
#     if None in target_classes.values():
#         return False  # 缺少headgear或clothes_upright类别
#
#     headgear_rect = target_classes['headgear']
#     clothes_upright_rect = target_classes['clothes_upright']
#
#     iou_value = iou(headgear_rect, clothes_upright_rect)
#     return iou_value >= threshold


def check_all_pairs_iou(info, threshold=0.95):
    """
    遍历info列表，寻找类别为headgear和clothes_upright的所有目标，
    将它们分别存放在各自列表中，然后对列表中的每个headgear和clothes_upright目标对比较交并比，
    如果存在交并比大于指定阈值的任意一对目标，则返回True
    """
    headgear_rects = []
    clothes_upright_rects = []

    for rect in info:
        if rect[-1] == 'headgear':
            headgear_rects.append(rect[:-1])  # 前四个元素表示矩形坐标
        elif rect[-1] == 'clothes_upright':
            clothes_upright_rects.append(rect[:-1])

    if not headgear_rects or not clothes_upright_rects:
        return False  # 缺少headgear或clothes_upright类别

    for headgear_rect in headgear_rects:
        for clothes_upright_rect in clothes_upright_rects:
            iou_value = iou(headgear_rect, clothes_upright_rect)
            if iou_value >= threshold:
                return True

    return False

# 示例调用
info = [[1309, 598, 1549, 1300, 'clothes_upright'],
        [1371, 598, 1491, 710, 'headgear'],
        [1309, 598, 1549, 1301, 'clothes_upright'],
        [1309, 598, 1549, 1301, 'headgear'],
        [1368, 1214, 1492, 1299, 'shoecover'],
        [1479, 1191, 1542, 1271, 'shoecover']]

result = check_all_pairs_iou(info)
print(result)  # 输出：True 或 False